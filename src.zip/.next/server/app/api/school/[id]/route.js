/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/school/[id]/route";
exports.ids = ["app/api/school/[id]/route"];
exports.modules = {

/***/ "(rsc)/./node_modules/mysql2/lib sync recursive ^cardinal.*$":
/*!****************************************************!*\
  !*** ./node_modules/mysql2/lib/ sync ^cardinal.*$ ***!
  \****************************************************/
/***/ ((module) => {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = () => ([]);
webpackEmptyContext.resolve = webpackEmptyContext;
webpackEmptyContext.id = "(rsc)/./node_modules/mysql2/lib sync recursive ^cardinal.*$";
module.exports = webpackEmptyContext;

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fschool%2F%5Bid%5D%2Froute&page=%2Fapi%2Fschool%2F%5Bid%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fschool%2F%5Bid%5D%2Froute.js&appDir=C%3A%5CUsers%5CAdmin%5CDesktop%5Crarome%5Crarome%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CAdmin%5CDesktop%5Crarome%5Crarome&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fschool%2F%5Bid%5D%2Froute&page=%2Fapi%2Fschool%2F%5Bid%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fschool%2F%5Bid%5D%2Froute.js&appDir=C%3A%5CUsers%5CAdmin%5CDesktop%5Crarome%5Crarome%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CAdmin%5CDesktop%5Crarome%5Crarome&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),\n/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"(rsc)/./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var C_Users_Admin_Desktop_rarome_rarome_src_app_api_school_id_route_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/app/api/school/[id]/route.js */ \"(rsc)/./src/app/api/school/[id]/route.js\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/school/[id]/route\",\n        pathname: \"/api/school/[id]\",\n        filename: \"route\",\n        bundlePath: \"app/api/school/[id]/route\"\n    },\n    resolvedPagePath: \"C:\\\\Users\\\\Admin\\\\Desktop\\\\rarome\\\\rarome\\\\src\\\\app\\\\api\\\\school\\\\[id]\\\\route.js\",\n    nextConfigOutput,\n    userland: C_Users_Admin_Desktop_rarome_rarome_src_app_api_school_id_route_js__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        workAsyncStorage,\n        workUnitAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIvaW5kZXguanM/bmFtZT1hcHAlMkZhcGklMkZzY2hvb2wlMkYlNUJpZCU1RCUyRnJvdXRlJnBhZ2U9JTJGYXBpJTJGc2Nob29sJTJGJTVCaWQlNUQlMkZyb3V0ZSZhcHBQYXRocz0mcGFnZVBhdGg9cHJpdmF0ZS1uZXh0LWFwcC1kaXIlMkZhcGklMkZzY2hvb2wlMkYlNUJpZCU1RCUyRnJvdXRlLmpzJmFwcERpcj1DJTNBJTVDVXNlcnMlNUNBZG1pbiU1Q0Rlc2t0b3AlNUNyYXJvbWUlNUNyYXJvbWUlNUNzcmMlNUNhcHAmcGFnZUV4dGVuc2lvbnM9dHN4JnBhZ2VFeHRlbnNpb25zPXRzJnBhZ2VFeHRlbnNpb25zPWpzeCZwYWdlRXh0ZW5zaW9ucz1qcyZyb290RGlyPUMlM0ElNUNVc2VycyU1Q0FkbWluJTVDRGVza3RvcCU1Q3Jhcm9tZSU1Q3Jhcm9tZSZpc0Rldj10cnVlJnRzY29uZmlnUGF0aD10c2NvbmZpZy5qc29uJmJhc2VQYXRoPSZhc3NldFByZWZpeD0mbmV4dENvbmZpZ091dHB1dD0mcHJlZmVycmVkUmVnaW9uPSZtaWRkbGV3YXJlQ29uZmlnPWUzMCUzRCEiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBK0Y7QUFDdkM7QUFDcUI7QUFDZ0M7QUFDN0c7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLHlHQUFtQjtBQUMzQztBQUNBLGNBQWMsa0VBQVM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLFlBQVk7QUFDWixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsUUFBUSxzREFBc0Q7QUFDOUQ7QUFDQSxXQUFXLDRFQUFXO0FBQ3RCO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDMEY7O0FBRTFGIiwic291cmNlcyI6WyIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXBwUm91dGVSb3V0ZU1vZHVsZSB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL3JvdXRlLW1vZHVsZXMvYXBwLXJvdXRlL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvcm91dGUta2luZFwiO1xuaW1wb3J0IHsgcGF0Y2hGZXRjaCBhcyBfcGF0Y2hGZXRjaCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2xpYi9wYXRjaC1mZXRjaFwiO1xuaW1wb3J0ICogYXMgdXNlcmxhbmQgZnJvbSBcIkM6XFxcXFVzZXJzXFxcXEFkbWluXFxcXERlc2t0b3BcXFxccmFyb21lXFxcXHJhcm9tZVxcXFxzcmNcXFxcYXBwXFxcXGFwaVxcXFxzY2hvb2xcXFxcW2lkXVxcXFxyb3V0ZS5qc1wiO1xuLy8gV2UgaW5qZWN0IHRoZSBuZXh0Q29uZmlnT3V0cHV0IGhlcmUgc28gdGhhdCB3ZSBjYW4gdXNlIHRoZW0gaW4gdGhlIHJvdXRlXG4vLyBtb2R1bGUuXG5jb25zdCBuZXh0Q29uZmlnT3V0cHV0ID0gXCJcIlxuY29uc3Qgcm91dGVNb2R1bGUgPSBuZXcgQXBwUm91dGVSb3V0ZU1vZHVsZSh7XG4gICAgZGVmaW5pdGlvbjoge1xuICAgICAgICBraW5kOiBSb3V0ZUtpbmQuQVBQX1JPVVRFLFxuICAgICAgICBwYWdlOiBcIi9hcGkvc2Nob29sL1tpZF0vcm91dGVcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL2FwaS9zY2hvb2wvW2lkXVwiLFxuICAgICAgICBmaWxlbmFtZTogXCJyb3V0ZVwiLFxuICAgICAgICBidW5kbGVQYXRoOiBcImFwcC9hcGkvc2Nob29sL1tpZF0vcm91dGVcIlxuICAgIH0sXG4gICAgcmVzb2x2ZWRQYWdlUGF0aDogXCJDOlxcXFxVc2Vyc1xcXFxBZG1pblxcXFxEZXNrdG9wXFxcXHJhcm9tZVxcXFxyYXJvbWVcXFxcc3JjXFxcXGFwcFxcXFxhcGlcXFxcc2Nob29sXFxcXFtpZF1cXFxccm91dGUuanNcIixcbiAgICBuZXh0Q29uZmlnT3V0cHV0LFxuICAgIHVzZXJsYW5kXG59KTtcbi8vIFB1bGwgb3V0IHRoZSBleHBvcnRzIHRoYXQgd2UgbmVlZCB0byBleHBvc2UgZnJvbSB0aGUgbW9kdWxlLiBUaGlzIHNob3VsZFxuLy8gYmUgZWxpbWluYXRlZCB3aGVuIHdlJ3ZlIG1vdmVkIHRoZSBvdGhlciByb3V0ZXMgdG8gdGhlIG5ldyBmb3JtYXQuIFRoZXNlXG4vLyBhcmUgdXNlZCB0byBob29rIGludG8gdGhlIHJvdXRlLlxuY29uc3QgeyB3b3JrQXN5bmNTdG9yYWdlLCB3b3JrVW5pdEFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MgfSA9IHJvdXRlTW9kdWxlO1xuZnVuY3Rpb24gcGF0Y2hGZXRjaCgpIHtcbiAgICByZXR1cm4gX3BhdGNoRmV0Y2goe1xuICAgICAgICB3b3JrQXN5bmNTdG9yYWdlLFxuICAgICAgICB3b3JrVW5pdEFzeW5jU3RvcmFnZVxuICAgIH0pO1xufVxuZXhwb3J0IHsgcm91dGVNb2R1bGUsIHdvcmtBc3luY1N0b3JhZ2UsIHdvcmtVbml0QXN5bmNTdG9yYWdlLCBzZXJ2ZXJIb29rcywgcGF0Y2hGZXRjaCwgIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFwcC1yb3V0ZS5qcy5tYXAiXSwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fschool%2F%5Bid%5D%2Froute&page=%2Fapi%2Fschool%2F%5Bid%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fschool%2F%5Bid%5D%2Froute.js&appDir=C%3A%5CUsers%5CAdmin%5CDesktop%5Crarome%5Crarome%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CAdmin%5CDesktop%5Crarome%5Crarome&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(rsc)/./src/app/api/school/[id]/route.js":
/*!******************************************!*\
  !*** ./src/app/api/school/[id]/route.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ GET),\n/* harmony export */   PUT: () => (/* binding */ PUT)\n/* harmony export */ });\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n/* harmony import */ var _db__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../db */ \"(rsc)/./src/app/db.js\");\n// import { NextResponse } from \"next/server\";\n// import { database } from \"../../../db\"; \n// export async function GET(req, context) {\n//   const { id } = context.params;\n//   try {\n//     const [rows] = await  database.query(\"SELECT * FROM schools WHERE id = ?\", [id]);\n//     if (rows.length === 0) {\n//       return NextResponse.json({ error: \"School not found\" }, { status: 404 });\n//     }\n//     return NextResponse.json(rows[0]); // Send single school data\n//   } catch (error) {\n//     console.error(error);\n//     return NextResponse.json({ error: \"Database Error\" }, { status: 500 });\n//   }\n// }\n// export async function PUT(req, { params }) {\n//   const { id } = params;\n//   const body = await req.json();\n//   try {\n//     await database.query(\n//       \"UPDATE schools SET name = ?, description = ?, contact_email = ?, contact_phone = ?, address = ? WHERE id = ?\",\n//       [body.name, body.description, body.contact_email, body.contact_phone, body.address, id]\n//     );\n//     const [updatedRows] = await database.query(\"SELECT * FROM schools WHERE id = ?\", [id]);\n//     return Response.json(updatedRows[0]);\n//   } catch (error) {\n//     console.error(\"Error updating school:\", error);\n//     return new Response(\"Error updating school\", { status: 500 });\n//   }\n// }\n\n\nasync function GET(req, context) {\n    const { id } = context.params;\n    try {\n        const [rows] = await _db__WEBPACK_IMPORTED_MODULE_1__.database.query(\"SELECT * FROM schools WHERE id = ?\", [\n            id\n        ]);\n        if (rows.length === 0) {\n            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                error: \"School not found\"\n            }, {\n                status: 404\n            });\n        }\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json(rows[0]);\n    } catch (error) {\n        console.error(error);\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            error: \"Database Error\"\n        }, {\n            status: 500\n        });\n    }\n}\nasync function PUT(req, { params }) {\n    const { id } = params;\n    const body = await req.json();\n    try {\n        await _db__WEBPACK_IMPORTED_MODULE_1__.database.query(\"UPDATE schools SET name = ?, description = ?, contact_email = ?, contact_phone = ? WHERE id = ?\", [\n            body.name,\n            body.description,\n            body.contact_email,\n            body.contact_phone,\n            id\n        ]);\n        const [updatedRows] = await _db__WEBPACK_IMPORTED_MODULE_1__.database.query(\"SELECT * FROM schools WHERE id = ?\", [\n            id\n        ]);\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json(updatedRows[0]); // <-- Corrected\n    } catch (error) {\n        console.error(\"Error updating school:\", error);\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            error: \"Error updating school\"\n        }, {\n            status: 500\n        });\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2FwaS9zY2hvb2wvW2lkXS9yb3V0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUEsOENBQThDO0FBQzlDLDJDQUEyQztBQUUzQyw0Q0FBNEM7QUFDNUMsbUNBQW1DO0FBQ25DLFVBQVU7QUFDVix3RkFBd0Y7QUFDeEYsK0JBQStCO0FBQy9CLGtGQUFrRjtBQUNsRixRQUFRO0FBQ1Isb0VBQW9FO0FBQ3BFLHNCQUFzQjtBQUN0Qiw0QkFBNEI7QUFDNUIsOEVBQThFO0FBQzlFLE1BQU07QUFDTixJQUFJO0FBRUosK0NBQStDO0FBQy9DLDJCQUEyQjtBQUMzQixtQ0FBbUM7QUFFbkMsVUFBVTtBQUNWLDRCQUE0QjtBQUM1Qix3SEFBd0g7QUFDeEgsZ0dBQWdHO0FBQ2hHLFNBQVM7QUFFVCw4RkFBOEY7QUFDOUYsNENBQTRDO0FBQzVDLHNCQUFzQjtBQUN0QixzREFBc0Q7QUFDdEQscUVBQXFFO0FBQ3JFLE1BQU07QUFDTixJQUFJO0FBRXVDO0FBQ0o7QUFFaEMsZUFBZUUsSUFBSUMsR0FBRyxFQUFFQyxPQUFPO0lBQ3BDLE1BQU0sRUFBRUMsRUFBRSxFQUFFLEdBQUdELFFBQVFFLE1BQU07SUFDN0IsSUFBSTtRQUNGLE1BQU0sQ0FBQ0MsS0FBSyxHQUFHLE1BQU1OLHlDQUFRQSxDQUFDTyxLQUFLLENBQUMsc0NBQXNDO1lBQUNIO1NBQUc7UUFDOUUsSUFBSUUsS0FBS0UsTUFBTSxLQUFLLEdBQUc7WUFDckIsT0FBT1QscURBQVlBLENBQUNVLElBQUksQ0FBQztnQkFBRUMsT0FBTztZQUFtQixHQUFHO2dCQUFFQyxRQUFRO1lBQUk7UUFDeEU7UUFDQSxPQUFPWixxREFBWUEsQ0FBQ1UsSUFBSSxDQUFDSCxJQUFJLENBQUMsRUFBRTtJQUNsQyxFQUFFLE9BQU9JLE9BQU87UUFDZEUsUUFBUUYsS0FBSyxDQUFDQTtRQUNkLE9BQU9YLHFEQUFZQSxDQUFDVSxJQUFJLENBQUM7WUFBRUMsT0FBTztRQUFpQixHQUFHO1lBQUVDLFFBQVE7UUFBSTtJQUN0RTtBQUNGO0FBRU8sZUFBZUUsSUFBSVgsR0FBRyxFQUFFLEVBQUVHLE1BQU0sRUFBRTtJQUN2QyxNQUFNLEVBQUVELEVBQUUsRUFBRSxHQUFHQztJQUNmLE1BQU1TLE9BQU8sTUFBTVosSUFBSU8sSUFBSTtJQUUzQixJQUFJO1FBQ0YsTUFBTVQseUNBQVFBLENBQUNPLEtBQUssQ0FDbEIsbUdBQ0E7WUFBQ08sS0FBS0MsSUFBSTtZQUFFRCxLQUFLRSxXQUFXO1lBQUVGLEtBQUtHLGFBQWE7WUFBRUgsS0FBS0ksYUFBYTtZQUFFZDtTQUFHO1FBRzNFLE1BQU0sQ0FBQ2UsWUFBWSxHQUFHLE1BQU1uQix5Q0FBUUEsQ0FBQ08sS0FBSyxDQUFDLHNDQUFzQztZQUFDSDtTQUFHO1FBQ3JGLE9BQU9MLHFEQUFZQSxDQUFDVSxJQUFJLENBQUNVLFdBQVcsQ0FBQyxFQUFFLEdBQUcsZ0JBQWdCO0lBQzVELEVBQUUsT0FBT1QsT0FBTztRQUNkRSxRQUFRRixLQUFLLENBQUMsMEJBQTBCQTtRQUN4QyxPQUFPWCxxREFBWUEsQ0FBQ1UsSUFBSSxDQUFDO1lBQUVDLE9BQU87UUFBd0IsR0FBRztZQUFFQyxRQUFRO1FBQUk7SUFDN0U7QUFDRiIsInNvdXJjZXMiOlsiQzpcXFVzZXJzXFxBZG1pblxcRGVza3RvcFxccmFyb21lXFxyYXJvbWVcXHNyY1xcYXBwXFxhcGlcXHNjaG9vbFxcW2lkXVxccm91dGUuanMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gaW1wb3J0IHsgTmV4dFJlc3BvbnNlIH0gZnJvbSBcIm5leHQvc2VydmVyXCI7XHJcbi8vIGltcG9ydCB7IGRhdGFiYXNlIH0gZnJvbSBcIi4uLy4uLy4uL2RiXCI7IFxyXG5cclxuLy8gZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIEdFVChyZXEsIGNvbnRleHQpIHtcclxuLy8gICBjb25zdCB7IGlkIH0gPSBjb250ZXh0LnBhcmFtcztcclxuLy8gICB0cnkge1xyXG4vLyAgICAgY29uc3QgW3Jvd3NdID0gYXdhaXQgIGRhdGFiYXNlLnF1ZXJ5KFwiU0VMRUNUICogRlJPTSBzY2hvb2xzIFdIRVJFIGlkID0gP1wiLCBbaWRdKTtcclxuLy8gICAgIGlmIChyb3dzLmxlbmd0aCA9PT0gMCkge1xyXG4vLyAgICAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBlcnJvcjogXCJTY2hvb2wgbm90IGZvdW5kXCIgfSwgeyBzdGF0dXM6IDQwNCB9KTtcclxuLy8gICAgIH1cclxuLy8gICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbihyb3dzWzBdKTsgLy8gU2VuZCBzaW5nbGUgc2Nob29sIGRhdGFcclxuLy8gICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XHJcbi8vICAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBlcnJvcjogXCJEYXRhYmFzZSBFcnJvclwiIH0sIHsgc3RhdHVzOiA1MDAgfSk7XHJcbi8vICAgfVxyXG4vLyB9XHJcblxyXG4vLyBleHBvcnQgYXN5bmMgZnVuY3Rpb24gUFVUKHJlcSwgeyBwYXJhbXMgfSkge1xyXG4vLyAgIGNvbnN0IHsgaWQgfSA9IHBhcmFtcztcclxuLy8gICBjb25zdCBib2R5ID0gYXdhaXQgcmVxLmpzb24oKTtcclxuXHJcbi8vICAgdHJ5IHtcclxuLy8gICAgIGF3YWl0IGRhdGFiYXNlLnF1ZXJ5KFxyXG4vLyAgICAgICBcIlVQREFURSBzY2hvb2xzIFNFVCBuYW1lID0gPywgZGVzY3JpcHRpb24gPSA/LCBjb250YWN0X2VtYWlsID0gPywgY29udGFjdF9waG9uZSA9ID8sIGFkZHJlc3MgPSA/IFdIRVJFIGlkID0gP1wiLFxyXG4vLyAgICAgICBbYm9keS5uYW1lLCBib2R5LmRlc2NyaXB0aW9uLCBib2R5LmNvbnRhY3RfZW1haWwsIGJvZHkuY29udGFjdF9waG9uZSwgYm9keS5hZGRyZXNzLCBpZF1cclxuLy8gICAgICk7XHJcblxyXG4vLyAgICAgY29uc3QgW3VwZGF0ZWRSb3dzXSA9IGF3YWl0IGRhdGFiYXNlLnF1ZXJ5KFwiU0VMRUNUICogRlJPTSBzY2hvb2xzIFdIRVJFIGlkID0gP1wiLCBbaWRdKTtcclxuLy8gICAgIHJldHVybiBSZXNwb25zZS5qc29uKHVwZGF0ZWRSb3dzWzBdKTtcclxuLy8gICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIHNjaG9vbDpcIiwgZXJyb3IpO1xyXG4vLyAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcIkVycm9yIHVwZGF0aW5nIHNjaG9vbFwiLCB7IHN0YXR1czogNTAwIH0pO1xyXG4vLyAgIH1cclxuLy8gfVxyXG5cclxuaW1wb3J0IHsgTmV4dFJlc3BvbnNlIH0gZnJvbSBcIm5leHQvc2VydmVyXCI7XHJcbmltcG9ydCB7IGRhdGFiYXNlIH0gZnJvbSBcIi4uLy4uLy4uL2RiXCI7XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gR0VUKHJlcSwgY29udGV4dCkge1xyXG4gIGNvbnN0IHsgaWQgfSA9IGNvbnRleHQucGFyYW1zO1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBbcm93c10gPSBhd2FpdCBkYXRhYmFzZS5xdWVyeShcIlNFTEVDVCAqIEZST00gc2Nob29scyBXSEVSRSBpZCA9ID9cIiwgW2lkXSk7XHJcbiAgICBpZiAocm93cy5sZW5ndGggPT09IDApIHtcclxuICAgICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHsgZXJyb3I6IFwiU2Nob29sIG5vdCBmb3VuZFwiIH0sIHsgc3RhdHVzOiA0MDQgfSk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24ocm93c1swXSk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xyXG4gICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHsgZXJyb3I6IFwiRGF0YWJhc2UgRXJyb3JcIiB9LCB7IHN0YXR1czogNTAwIH0pO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIFBVVChyZXEsIHsgcGFyYW1zIH0pIHtcclxuICBjb25zdCB7IGlkIH0gPSBwYXJhbXM7XHJcbiAgY29uc3QgYm9keSA9IGF3YWl0IHJlcS5qc29uKCk7XHJcblxyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBkYXRhYmFzZS5xdWVyeShcclxuICAgICAgXCJVUERBVEUgc2Nob29scyBTRVQgbmFtZSA9ID8sIGRlc2NyaXB0aW9uID0gPywgY29udGFjdF9lbWFpbCA9ID8sIGNvbnRhY3RfcGhvbmUgPSA/IFdIRVJFIGlkID0gP1wiLFxyXG4gICAgICBbYm9keS5uYW1lLCBib2R5LmRlc2NyaXB0aW9uLCBib2R5LmNvbnRhY3RfZW1haWwsIGJvZHkuY29udGFjdF9waG9uZSwgaWRdXHJcbiAgICApO1xyXG5cclxuICAgIGNvbnN0IFt1cGRhdGVkUm93c10gPSBhd2FpdCBkYXRhYmFzZS5xdWVyeShcIlNFTEVDVCAqIEZST00gc2Nob29scyBXSEVSRSBpZCA9ID9cIiwgW2lkXSk7XHJcbiAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24odXBkYXRlZFJvd3NbMF0pOyAvLyA8LS0gQ29ycmVjdGVkXHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBzY2hvb2w6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IGVycm9yOiBcIkVycm9yIHVwZGF0aW5nIHNjaG9vbFwiIH0sIHsgc3RhdHVzOiA1MDAgfSk7XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6WyJOZXh0UmVzcG9uc2UiLCJkYXRhYmFzZSIsIkdFVCIsInJlcSIsImNvbnRleHQiLCJpZCIsInBhcmFtcyIsInJvd3MiLCJxdWVyeSIsImxlbmd0aCIsImpzb24iLCJlcnJvciIsInN0YXR1cyIsImNvbnNvbGUiLCJQVVQiLCJib2R5IiwibmFtZSIsImRlc2NyaXB0aW9uIiwiY29udGFjdF9lbWFpbCIsImNvbnRhY3RfcGhvbmUiLCJ1cGRhdGVkUm93cyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./src/app/api/school/[id]/route.js\n");

/***/ }),

/***/ "(rsc)/./src/app/db.js":
/*!***********************!*\
  !*** ./src/app/db.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   database: () => (/* binding */ database)\n/* harmony export */ });\n/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mysql2/promise */ \"(rsc)/./node_modules/mysql2/promise.js\");\n\nconst database = mysql2_promise__WEBPACK_IMPORTED_MODULE_0__.createPool({\n    host: 'localhost',\n    user: 'root',\n    password: '',\n    database: 'rarome'\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2RiLmpzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQW1DO0FBRTVCLE1BQU1DLFdBQVdELHNEQUFnQixDQUFDO0lBQ3ZDRyxNQUFNO0lBQ05DLE1BQU07SUFDTkMsVUFBVTtJQUNWSixVQUFVO0FBQ1osR0FBRyIsInNvdXJjZXMiOlsiQzpcXFVzZXJzXFxBZG1pblxcRGVza3RvcFxccmFyb21lXFxyYXJvbWVcXHNyY1xcYXBwXFxkYi5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbXlzcWwgZnJvbSAnbXlzcWwyL3Byb21pc2UnO1xyXG5cclxuZXhwb3J0IGNvbnN0IGRhdGFiYXNlID0gbXlzcWwuY3JlYXRlUG9vbCh7XHJcbiAgaG9zdDogJ2xvY2FsaG9zdCcsICAgICBcclxuICB1c2VyOiAncm9vdCcsXHJcbiAgcGFzc3dvcmQ6ICcnLFxyXG4gIGRhdGFiYXNlOiAncmFyb21lJywgXHJcbn0pO1xyXG4iXSwibmFtZXMiOlsibXlzcWwiLCJkYXRhYmFzZSIsImNyZWF0ZVBvb2wiLCJob3N0IiwidXNlciIsInBhc3N3b3JkIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./src/app/db.js\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app-render/after-task-async-storage.external":
/*!***********************************************************************************!*\
  !*** external "next/dist/server/app-render/after-task-async-storage.external.js" ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ "../app-render/work-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/server/app-render/work-async-storage.external.js" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ "./work-unit-async-storage.external":
/*!**********************************************************************************!*\
  !*** external "next/dist/server/app-render/work-unit-async-storage.external.js" ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ "net":
/*!**********************!*\
  !*** external "net" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "process":
/*!**************************!*\
  !*** external "process" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "string_decoder":
/*!*********************************!*\
  !*** external "string_decoder" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ "timers":
/*!*************************!*\
  !*** external "timers" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("timers");

/***/ }),

/***/ "tls":
/*!**********************!*\
  !*** external "tls" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/mysql2","vendor-chunks/aws-ssl-profiles","vendor-chunks/iconv-lite","vendor-chunks/long","vendor-chunks/named-placeholders","vendor-chunks/denque","vendor-chunks/is-property","vendor-chunks/lru.min","vendor-chunks/sqlstring","vendor-chunks/seq-queue","vendor-chunks/generate-function","vendor-chunks/safer-buffer"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fschool%2F%5Bid%5D%2Froute&page=%2Fapi%2Fschool%2F%5Bid%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fschool%2F%5Bid%5D%2Froute.js&appDir=C%3A%5CUsers%5CAdmin%5CDesktop%5Crarome%5Crarome%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CAdmin%5CDesktop%5Crarome%5Crarome&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();